library(devtools)
library(nflscrapR)
library(tidyverse)
library(teamcolors)
library(dplyr)

#Getting the data
post <- scrape_game_ids(2019, type = "post")
superbowl19 <- post %>%
  filter(home_team == "KC", away_team == "SF") %>%
  pull(game_id) %>%
  scrape_json_play_by_play()

#Pulling out and setting team colors
nfl_teamcolors <- teamcolors %>% filter(league == 'nfl')

sf_color <- nfl_teamcolors %>% filter(name == "San Francisco 49ers") %>%
  pull(secondary)

kc_color <- nfl_teamcolors %>%
  filter(name == "Kansas City Chiefs") %>%
  pull(primary)

#Win-Probability Chart
superbowl19 %>% filter(!is.na(home_wp),
                       !is.na(away_wp)) %>%
  dplyr::select(game_seconds_remaining,
                home_wp,
                away_wp) %>%
  gather(team, wpa, -game_seconds_remaining) %>%
  ggplot(aes(x = game_seconds_remaining, y = wpa, color = team)) +
  geom_line(size = 2) +
  geom_hline(yintercept = 0.5, color = "gray", linetype = "dashed") +
  scale_color_manual(labels = c("SF", "KC"),
                     values = c(sf_color, kc_color),
                     guide = FALSE) +
  scale_x_reverse(breaks = seq(0, 3600, 300)) + 
  annotate("text", x = 3000, y = .75, label = "SF", color = sf_color, size = 8) + 
  annotate("text", x = 3000, y = .25, label = "KC", color = kc_color, size = 8) +
  geom_vline(xintercept = 900, linetype = "dashed", black) + 
  geom_vline(xintercept = 1800, linetype = "dashed", black) + 
  geom_vline(xintercept = 2700, linetype = "dashed", black) + 
  geom_vline(xintercept = 0, linetype = "dashed", black) + 
  labs(
    x = "Time Remaining (seconds)",
    y = "Win Probability",
    title = "Super Bowl LIV Probability Chart",
    subtitle = "San Francisco 49ers vs. Kansas City Chiefs",
    caption = "Data from nflscrapR"
  ) + theme_bw()
  
#will only examine the key plays after halftime.
second_half <- superbowl19[superbowl19$game_half == "Half2",]

#Gathering only relevant data
half2_plays <- second_half %>% select(play_id, total_home_score, total_away_score,
                                      game_seconds_remaining, defteam, desc, time, epa, wpa, 
                                      home_wp, away_wp)

#When was KC's win-probability the lowest?
second_half[which.min(half2_plays$home_wp),c("home_wp", "game_seconds_remaining")] #with 637 seconds left - 11.1%
second_half[which.max(half2_plays$away_wp),c("away_wp", "game_seconds_remaining")] #SF - 88.9%

#What happened between 1800 and 637 seconds left in the game? - Examining the key plays with the highest wpa
#Basically, how did the wp's for both teams get where it was with 637 seconds left?

