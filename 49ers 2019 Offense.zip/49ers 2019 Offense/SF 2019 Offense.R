library(tidyverse)
library(nflscrapR)
library(progress)
library(data.table)
library(teamcolors)
library(ggimage)
library(extrafont)
library(scales)
library(ggnewscale)
library(grid)
library(readxl)
library(ggthemes)
library(stringr)

# Read the data
excel_sheets("NFL Team Stats.xlsx")
team_stats_2019 <- as.tibble(read_excel("NFL Team Stats.xlsx", sheet = 2)) %>% arrange(PPG)
team_stats_2018 <- as.tibble(read_excel("NFL Team Stats.xlsx", sheet = 3)) %>% arrange(PPG)

#-------------------------------------- 2018 --------------------------------------
avg_2018_PPG <- mean(team_stats_2018$PPG)
SF_Colors <- teamcolors %>% filter(name == 'San Francisco 49ers')

# 2018 Points per game of all 32 teams
team_stats_2018 %>% 
  mutate(Teams = factor(Teams, levels = Teams)) %>%

# Plot
  ggplot(aes(x = Teams, y = PPG)) + 
  geom_col(fill = ifelse(team_stats_2018$Teams == '49ers', SF_Colors$secondary, "#D3D3D3")) + 
  coord_flip() + geom_hline(yintercept = avg_2018_PPG, color = 'black', linetype = 'dotted') +
  annotate('text', x = avg_2018_PPG - 8, y = 24.5, label = 'Average\nPPG\n(23.3)',
           vjust = 1, size = 3, color = 'black') +
  
  labs(y = "Points Per Game", 
       title = 'With an injured Jimmy Garoppolo, the 49ers were one of the worst teams', 
       subtitle = '2018 Points Per Game of all NFL Teams',
       caption = 'Data: Pro Football Reference | Plot: Ivan Patel') +

# Finishing Touches
  geom_text(aes(label = round(PPG, 2)), size = 3, nudge_y = -5) + theme_tufte() +
  theme(axis.text.x = element_text(color = 'black', size = 10),
        axis.text.y = element_text(color = 'black', size = 10, 
                                   margin = margin(0, -30, 0, 10)),
        axis.ticks = element_blank(), 
        axis.title.y = element_blank(), 
        plot.title = element_text(size = 18, hjust = 0.5), 
        plot.subtitle = element_text(face = 'italic', size = 13))
  

#-------------------------------------- 2019 --------------------------------------
avg_2019_PPG <- mean(team_stats_2019$PPG)

# 2019 Points Per Game of all 32 teams
team_stats_2019 %>%
  mutate(Teams = factor(Teams, levels = Teams)) %>%
  
# Plot
  ggplot(aes(x = Teams, y = PPG)) + 
  geom_col(fill = ifelse(team_stats_2019$Teams == '49ers', SF_Colors$secondary, "#D3D3D3")) + 
  coord_flip() + labs(title = 'With a healthy team, the 49ers had the second highest scoring offense',
                      subtitle = '2019 Points Per Game of all NFL Teams',
                      caption = 'Data: Pro Football Reference | Plot: Ivan Patel',
                      y = 'Points Per Game') +
  
# Finishing Touches
  geom_text(aes(label = round(PPG, 2)), color = 'black', size = 3, nudge_y = -3.856) + 
  geom_hline(yintercept = avg_2019_PPG, linetype = 'dotted', color = 'black') +
  annotate('text', x = avg_2019_PPG - 10, y = 24, label = 'Average\nPPG\n(22.8)', 
           vjust = 1, size = 3, color = 'black') +
  
# Themes
  theme_tufte() +
  theme(plot.title = element_text(size = 18, hjust = 0.5),
        plot.subtitle = element_text(face = 'italic', size = 13),
        axis.ticks = element_blank(),
        axis.text.x = element_text(color = 'black', size = 10), 
        axis.text.y = element_text(color = 'black', size = 10, 
                                   margin = margin(0, -30, 0, 10)),
        axis.title.y = element_blank()) 

#--------------------------------  Offensive Efficiency #--------------------------------  

# Reading the play by play data for 2019 season
pbp <- read_csv(url("https://github.com/ryurko/nflscrapR-data/raw/master/play_by_play_data/regular_season/reg_pbp_2019.csv"))

nfl_logos_df <- read_csv("https://raw.githubusercontent.com/statsbylopez/BlogPosts/master/nfl_teamlogos.csv")

SF_home_pbp <- pbp %>% filter(home_team == 'SF')
SF_away_pbp <- pbp %>% filter(away_team == 'SF')
sf_pbp_2019 <- SF_home_pbp %>% bind_rows(SF_away_pbp)

#-------------------------- Data Cleaning #-------------------------- 
# https://gist.github.com/guga31bb/5634562c5a2a7b1e9961ac9b6c568701 
# - Couldn't have done it without Ben Baldwin

# Let's only keep the pass, run, no plays due to penalties, and plays that have an epa value
sf_pbp_2019_rp <- sf_pbp_2019 %>% 
  filter(!is.na(epa), play_type == 'no_play' | play_type == 'pass' | play_type == 'run')

# Looking at some of the "No Plays"
sf_pbp_2019_rp %>% filter(play_type == 'no_play') %>% select(desc, pass_attempt, rush_attempt) %>% head()
# -Most of these are attempted pass or rush plays that should count when calculating EPA per play.

# Let's fix that
sf_pbp_2019_rp <- sf_pbp_2019_rp %>% mutate(
  pass = if_else(str_detect(desc, "( pass)|(sacked)|(scramble)"), 1, 0),
  rush = if_else(str_detect(desc, "(left end)|(left tackle)|(left guard)|(up the middle)|(right guard)|(right tackle)|(right end)") & pass == 0, 1, 0),
  success = ifelse(epa > 0, 1 , 0)
) 

sf_pbp_2019_rp %>% select(desc, pass, rush) %>% head()

# Keeping only the pass and rushing plays
sf_pbp_2019_rp <- sf_pbp_2019_rp %>% filter(pass == 1 | rush == 1)
sum(sf_pbp_2019_rp$pass) #1200
sum(sf_pbp_2019_rp$rush) #847 - Total = 2047. 

# Basic analysis - Rushing Plays
(sf_rushing_success <- sf_pbp_2019_rp %>% filter(rush == 1, down <= 4) %>% 
    group_by(rusher_player_name) %>%
    summarize(mean_epa = mean(epa), success_rate = mean(success), ypc = mean(yards_gained), 
              plays = n()) %>% arrange(desc(mean_epa)) %>% filter(plays > 40) )
# Only Raheem Mostert had a positive EPA per rush, and it was just above zero.

# Basic analysis - Passing Plays
sf_passing_success <- sf_pbp_2019_rp %>% filter(pass == 1, down <= 4) %>%
  group_by(passer_player_name) %>%
  summarize(mean_epa = mean(epa), success_rate = mean(success), ypa = mean(yards_gained),
            plays = n()) %>% arrange(desc(mean_epa)) %>% filter(plays > 120)

pbp2 <- pbp %>% mutate(
  pass = if_else(str_detect(desc, "( pass)|(sacked)|(scramble)"), 1, 0),
  rush = if_else(str_detect(desc, "(left end)|(left tackle)|(left guard)|(up the middle)|(right guard)|(right tackle)|(right end)") & pass == 0, 1, 0),
  success = ifelse(epa > 0, 1 , 0)
) 

pbp2 %>% filter(play_type == 'pass', down <= 4) %>%
  group_by(passer_player_name) %>%
  summarize(mean_epa = mean(epa), success_rate = mean(success), ypa = mean(yards_gained),
            plays = n()) %>% arrange(desc(mean_epa)) %>% filter(plays > 60)
# Jimmy garoppolo was 9th in mean epa per pass.

# Let's look at how pass happy the 49ers were compared to the rest of the league on early downs in 
# in the first half excluding the final 2 minutes of the half when everyone is pass-happy:
pass_happy_half_one <- pbp2 %>% 
  filter(wp > 0.2 & wp < 0.8 & down <= 2 & qtr <= 2 & half_seconds_remaining > 120) %>% 
  group_by(posteam) %>% summarize(mean_pass = mean(pass), plays = n()) %>% 
  arrange(mean_pass)

pass_happy_half_one <- pass_happy_half_one %>% left_join(nfl_logos_df, by = c('posteam' = 'team_code'))
pass_happy_half_one[7,4] <- 'Oakland Raiders'
pass_happy_half_one[7,5] <- nfl_logos_df[nfl_logos_df$team_code == 'LV', 'url', drop = TRUE]

pass_happy_half_two <- pbp2 %>% 
  filter(wp > 0.2 & wp < 0.8 & down <= 2 & qtr >= 3 & half_seconds_remaining > 240) %>% 
  group_by(posteam) %>% summarize(mean_pass = mean(pass), plays = n()) %>% 
  arrange(mean_pass)

# Plot
pass_happy_half_one %>% arrange(mean_pass) %>%
  mutate(posteam = factor(posteam, levels = posteam)) %>% 
  ggplot(aes(x = posteam, y = mean_pass)) +
  geom_image(aes(image = url), size = 0.035) +
  theme_tufte() +
  labs(x = 'Teams', title = 'On Avg, how often did the 49ers pass the ball on early downs?',
       subtitle = 'In first half',
       caption = 'Data: nflscrapr | Plot: Ivan Patel') + 
  
  theme(axis.title.y = element_blank(),
        plot.subtitle = element_text(face = 'italic', size = 11),
        plot.title = element_text(size = 15, hjust = 0.5), 
        axis.text.y = element_text(color = 'black', size = 12, face = 'bold'),
        axis.text.x = element_text(color = 'black', size = 11),
        panel.grid.major.y = element_line(color = 'grey92', size = 0.5)) + 
  scale_y_continuous(labels = function(x) paste0(x*100, "%"), limits = c(.1,.8)) +
  annotate('text', x = 'SF', y = 0.485 + .02, label = '48%', size = 4)
  # On Average, the 49ers threw the ball 48% of the time on early downs in the first half

# 10 teams with the highest average percent of pass plays on early downs
pass_happy_half_one %>% arrange(desc(mean_pass)) %>% 
  rename(Team = posteam, Avg_Percent_Pass_Plays = mean_pass, Plays = plays) %>%
  select(Team, Avg_Percent_Pass_Plays, Plays)

# 10 teams with the lowest average percent of pass plays on early downs
pass_happy_half_one %>% arrange(mean_pass) %>% 
  rename(Team = posteam, Avg_Percent_Pass_Plays = mean_pass, Plays = plays) %>%
  select(Team, Avg_Percent_Pass_Plays, Plays) %>% head(n = 10)





